**_Boss Room documentation_**

This sample project is an educational template that, alongside tutorials, teaches a specific approach to creating and networking in Unity. Boss Room has tools to help you learn how to build and network a small-scale cooperative game.

For further, more in-depth documentation, please refer to this project's README.md.

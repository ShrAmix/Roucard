# Unity Relay

* add `cloudProjectId`, `organizationId` and `projectName`in `ProjectSettings.asset` (or do it via the editor)
* add scoped registry to `manifest.json`
* add `com.unity.services.relay`, `com.unity.services.authentication`, `com.unity.transport` and `com.unity.multiplayer.transport.utp`
* update version of `com.unity.multiplayer.mlapi`

using System;

namespace Unity.BossRoom.ApplicationLifecycle.Messages
{
    public struct QuitApplicationMessage
    {
    }
}

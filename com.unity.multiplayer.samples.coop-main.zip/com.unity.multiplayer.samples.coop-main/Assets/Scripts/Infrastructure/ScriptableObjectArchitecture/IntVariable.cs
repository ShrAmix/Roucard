using UnityEngine;

namespace Unity.BossRoom.Infrastructure
{
    [CreateAssetMenu]
    public class IntVariable : ScriptableObject
    {
        public int Value;
    }
}

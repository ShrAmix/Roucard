---
name: Other Issues
about: Use this template for any other non-support related issues
title: ''
labels: stat:awaiting triage
assignees: ''

---

This template is for issues not covered by the other issue categories.
